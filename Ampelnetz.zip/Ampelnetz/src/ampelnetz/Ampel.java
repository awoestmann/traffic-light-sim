package ampelnetz;

public class Ampel extends AmpelnetzComponent{

	public Ampel() {
		componentType = ComponentType.AMPEL;
	}
}
